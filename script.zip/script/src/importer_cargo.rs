use sqlx::{PgPool, FromRow};
use anyhow::Result;

#[derive(Debug, FromRow)]
pub struct TabelaCargo {
    pub id: i32,
    pub codigo: String,
    pub nome: String,
}

pub struct ImportConfig {
    pub page_size: i64,
}

impl Default for ImportConfig {
    fn default() -> Self {
        Self { page_size: 500 }
    }
}

/// Importa dados da tabela_cargo de um banco origem para um destino
pub async fn import_tabela_cargo(
    source_pool: &PgPool,
    target_pool: &PgPool,
    config: ImportConfig,
) -> Result<()> {
    let mut offset: i64 = 0;

    loop {
        // buscar lote da origem
        let rows: Vec<TabelaCargo> = sqlx::query_as::<_, TabelaCargo>(
            "SELECT id, codigo, nome
             FROM tabela_cargo
             ORDER BY id
             LIMIT $1 OFFSET $2"
        )
        .bind(config.page_size)
        .bind(offset)
        .fetch_all(source_pool)
        .await?;

        if rows.is_empty() {
            println!("✅ Migração concluída");
            break;
        }

        println!("Migrando {} registros (offset {})", rows.len(), offset);

        for row in rows {
            sqlx::query(
                "INSERT INTO tabela_cargo (id, codigo, nome)
                 VALUES ($1, $2, $3)
                 ON CONFLICT (id) DO UPDATE
                   SET codigo = EXCLUDED.codigo,
                       nome = EXCLUDED.nome"
            )
            .bind(row.id)
            .bind(row.codigo)
            .bind(row.nome)
            .execute(target_pool)
            .await?;
        }

        offset += config.page_size;
    }

    Ok(())
}
