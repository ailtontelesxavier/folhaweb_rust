
use script::{ImportConfig, import_tabela_cargo};
use dotenv::dotenv;
use sqlx::PgPool;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    dotenv().ok();

    //let source_db = std::env::var("SOURCE_DATABASE_URL")?;

    let encoded_message = urlencoding::encode("1senha");

    let source_db = format!("postgresql+psycopg://sifomento:{}@10.99.1.49:5432/sifomento", encoded_message);

    //let source_db = std::env::var("SOURCE_DATABASE_URL").expect("SOURCE_DATABASE_URL must be set");
    let target_db = std::env::var("TARGET_DATABASE_URL").expect("TARGET_DATABASE_URL must be set");

    let source_pool = PgPool::connect(&source_db).await?;
    let target_pool = PgPool::connect(&target_db).await?;

    import_tabela_cargo(&source_pool, &target_pool, ImportConfig::default()).await?;

    Ok(())
}
